package com.Freelance.beans;

public class Project {
	private String titre;
	private String desc;
	private int budget; 
	private String cat;
	private String usernameB;
	/**
	 * @return the titre
	 */
	public String getTitre() {
		return titre;
	}
	/**
	 * @param titre the titre to set
	 */
	public void setTitre(String titre) {
		this.titre = titre;
	}
	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}
	/**
	 * @param desc the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}
	/**
	 * @return the budget
	 */
	public int getBudget() {
		return budget;
	}
	/**
	 * @param budget the budget to set
	 */
	public void setBudget(int budget) {
		this.budget = budget;
	}
	/**
	 * @return the cat
	 */
	public String getCat() {
		return cat;
	}
	/**
	 * @param cat the cat to set
	 */
	public void setCat(String cat) {
		this.cat = cat;
	}
	/**
	 * @return the usernameB
	 */
	/**
	 * @return the usernameB
	 */
	public String getusernameB() {
		return usernameB;
	}
	/**
	 * @param usernameB the usernameB to set
	 */
	public void setUsernameB(String usernameB) {
		this.usernameB = usernameB;
	}
	
}
